package HW6.Comandos;

public interface Command {
	void execute();
}
